package com.example.module_4.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import com.example.module_4.R
import com.example.module_4.databinding.ActivityNtextViewBinding

class NTextViewActivity : AppCompatActivity() {
    private lateinit var binding : ActivityNtextViewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNtextViewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnDone.setOnClickListener {
            val n = binding.etText.text.toString().toIntOrNull()
            binding.etContainer.removeAllViews()
            if (n != null && n > 0) {
                for (i in 1..n) {
                    val editText = EditText(this)
                    editText.hint = "Enter Your Detail $i"
                    binding.etContainer.addView(editText)
                }
            }
        }
    }
    }