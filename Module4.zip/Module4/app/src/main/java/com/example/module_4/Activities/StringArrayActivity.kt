package com.example.module_4.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import com.example.module_4.R
import com.example.module_4.databinding.ActivityStringArrayBinding

class StringArrayActivity : AppCompatActivity() {
    private lateinit var binding : ActivityStringArrayBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStringArrayBinding.inflate(layoutInflater)
        setContentView(binding.root)
        var string = resources.getStringArray(R.array.Days)
        val dayAdapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,string)
        binding.listView.adapter = dayAdapter
    }
}