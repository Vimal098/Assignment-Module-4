package com.example.module_4.Activities

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.module_4.R
import com.example.module_4.databinding.ActivityScreenColorBinding

class ScreenColorActivity : AppCompatActivity() {
    private lateinit var binding: ActivityScreenColorBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScreenColorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.blue.setOnClickListener {
               binding.linearLayout.setBackgroundColor(Color.BLUE)
        }
        binding.green.setOnClickListener {
               binding.linearLayout.setBackgroundColor(Color.GREEN)
        }
        binding.grey.setOnClickListener {
               binding.linearLayout.setBackgroundColor(Color.GRAY)
        }
        binding.yellow.setOnClickListener {
               binding.linearLayout.setBackgroundColor(Color.YELLOW)
        }
        binding.red.setOnClickListener {
               binding.linearLayout.setBackgroundColor(Color.RED)
        }
    }
}