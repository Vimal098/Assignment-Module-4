package com.example.module_4.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.module_4.databinding.ActivityShowNumberBinding

class ShowNumberActivity : AppCompatActivity() {
    private lateinit var binding: ActivityShowNumberBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShowNumberBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val first = intent.getIntExtra("first", 0)
        val second = intent.getIntExtra("second", 0)
        val number = numberbetween(first, second)
        binding.tvNumber.text = number.joinToString(",")
        }

    private fun numberbetween(start: Int, end: Int): List<Int> {
               return if (start<end){
                   (start..end).toList()
               }
        else{
                   (start downTo end).toList()
               }
    }

}

