package com.example.module_4.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.TypedValue
import com.example.module_4.R
import com.example.module_4.databinding.ActivityFontSizeBinding

class FontSizeActivity : AppCompatActivity() {
    private var font = 14f
     private lateinit var binding: ActivityFontSizeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFontSizeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.floatingActionButton.setOnClickListener {
            font  +=4f
            binding.textView3.setTextSize(TypedValue.COMPLEX_UNIT_SP,font)
        }
        binding.floatingActionButton2.setOnClickListener {
            font  -=4f
            binding.textView3.setTextSize(TypedValue.COMPLEX_UNIT_SP,font)
        }
    }
}