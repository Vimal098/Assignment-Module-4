package com.example.module_4.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import com.example.module_4.R
import com.example.module_4.databinding.ActivityVisibleTextBinding

class VisibleTextActivity : AppCompatActivity() {
    private lateinit var binding: ActivityVisibleTextBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVisibleTextBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnHide.setOnClickListener {
            binding.textView4.visibility = View.GONE
        }
        binding.btnShow.setOnClickListener {
            binding.textView4.visibility = VISIBLE
        }
    }

}
