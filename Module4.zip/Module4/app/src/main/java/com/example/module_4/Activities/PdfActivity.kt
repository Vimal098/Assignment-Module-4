package com.example.module_4.Activities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.module_4.R
import com.example.module_4.databinding.ActivityPdfBinding

class PdfActivity : AppCompatActivity() {
    private lateinit var binding : ActivityPdfBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnPdf.setOnClickListener {
            openpdf()
        }
    }

    private fun openpdf() {
        val pdffileuri = Uri.parse("https://www.adobe.com/support/products/enterprise/knowledgecenter/media/c4611_sample_explain.pdf")
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setDataAndType(pdffileuri,"application/pdf")
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        try {
            startActivity(intent)
        }catch (e : ActivityNotFoundException){
            Log.e("pdfActivity","Error Opening PDF : ${e.message}")
            Toast.makeText(this,"No Pdf Viewer App Installed or Error Opening PDF.",Toast.LENGTH_SHORT).show()
        }
    }
}