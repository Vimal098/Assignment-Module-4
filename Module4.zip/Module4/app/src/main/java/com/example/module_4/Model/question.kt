package com.example.module_4.Model

data class question(
    var id : Int,
    var que : String
)
