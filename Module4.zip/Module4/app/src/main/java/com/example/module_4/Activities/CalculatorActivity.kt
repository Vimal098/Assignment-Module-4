package com.example.module_4.Activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.module_4.databinding.ActivityNumberBinding

class CalculatorActivity : AppCompatActivity() {
    private lateinit var binding : ActivityNumberBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNumberBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.add.setOnClickListener {
            var a = binding.textView.text.toString().toInt()
            var b = binding.textView2.text.toString().toInt()
            binding.tvTextview.setText((a+b).toString())
        }
        binding.sub.setOnClickListener {
            var a = binding.textView.text.toString().toInt()
            var b = binding.textView2.text.toString().toInt()
            binding.tvTextview.setText((a-b).toString())
        }
        binding.mul.setOnClickListener {
            var a = binding.textView.text.toString().toInt()
            var b = binding.textView2.text.toString().toInt()
            binding.tvTextview.setText((a*b).toString())
        }
        binding.div.setOnClickListener {
            var a = binding.textView.text.toString().toInt()
            var b = binding.textView2.text.toString().toInt()
            binding.tvTextview.setText((a/b).toString())
        }
    }
}