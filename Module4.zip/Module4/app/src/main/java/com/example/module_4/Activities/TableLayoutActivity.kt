package com.example.module_4.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TableRow
import android.widget.TextView
import com.example.module_4.R
import com.example.module_4.databinding.ActivityTableLayoutBinding

class TableLayoutActivity : AppCompatActivity() {
    lateinit var binding : ActivityTableLayoutBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTableLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnAddrow.setOnClickListener {
            val tablerow = TableRow(this)
            val textView = TextView(this)
            textView.text = "New Text"
            tablerow.addView(textView)
            binding.tablelayout.addView(tablerow)
        }
    }
}