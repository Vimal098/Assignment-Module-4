package com.example.module_4.Activities
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.example.module_4.databinding.ActivityWebViewBinding

class WebView : AppCompatActivity() {
    private lateinit var binding: ActivityWebViewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWebViewBinding.inflate(layoutInflater)
        setContentView(binding.root)
       binding.webView.settings.javaScriptEnabled = true
        binding.webView.webViewClient = WebViewClient()
        binding.webView.webChromeClient = WebChromeClient()
        loadUrl("https://www.google.com")
        binding.btnBack.setOnClickListener {
            if (binding.webView.canGoBack()){
                binding.webView.goBack()
            }
        }
        binding.btnForward.setOnClickListener {
            if (binding.webView.canGoForward()){
                binding.webView.goForward()
            }
        }
    }

    private fun loadUrl(Url: String) {
          binding.webView.loadUrl(Url)
    }
}