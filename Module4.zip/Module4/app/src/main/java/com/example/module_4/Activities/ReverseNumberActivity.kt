package com.example.module_4.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.module_4.R
import com.example.module_4.databinding.ActivityReverseNumberBinding

class ReverseNumberActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReverseNumberBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReverseNumberBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.linearLayout.setOnClickListener {
            if (! binding.etNumber.text.isEmpty()){
           var c = StringBuffer(binding.etNumber.text.toString())
                binding.tvNumber.setText(c.reverse())
            }
        }

    }
}