package com.example.module_4.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.widget.Toolbar
import com.example.module_4.R
import com.example.module_4.databinding.ActivityCustomToolbarBinding

class CustomToolbarActivity : AppCompatActivity() {
    var degree = arrayOf("BCA", "MCA", "10TH", "12TH", "B.TECH", "M.TECH", "BSC", "MSC", "M.phill")
    private lateinit var arrayAdapter: ArrayAdapter<String>
    lateinit var binding: ActivityCustomToolbarBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomToolbarBinding.inflate(layoutInflater)
      setContentView(binding.root)
      var toolbar = binding.toolbar
        setSupportActionBar(toolbar)
        var degreeAdapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, degree)
        binding.degree.adapter = degreeAdapter
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.app_tool,menu)
        return true
    }
}