package com.example.module_4.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.module_4.Activities.CalculatorActivity
import com.example.module_4.Activities.CheckboxActivity
import com.example.module_4.Activities.CustomToolbarActivity
import com.example.module_4.Activities.FontSizeActivity
import com.example.module_4.Activities.MainActivity2
import com.example.module_4.Activities.NTextViewActivity
import com.example.module_4.Activities.NumberBetweenActivity
import com.example.module_4.Activities.PdfActivity
import com.example.module_4.Activities.ReverseNumberActivity
import com.example.module_4.Activities.ScreenColorActivity
import com.example.module_4.Activities.StringArrayActivity
import com.example.module_4.Activities.TableLayoutActivity
import com.example.module_4.Activities.VisibleTextActivity
import com.example.module_4.Activities.WebView
import com.example.module_4.Model.question
import com.example.module_4.databinding.QuestionListBinding


class QuestionListAdapter(var context: Context,var quesList: MutableList<question>):
RecyclerView.Adapter<QuestionListAdapter.MyViewHolder>() {
    class MyViewHolder(val binding: QuestionListBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): QuestionListAdapter.MyViewHolder {

        var binding = QuestionListBinding.inflate(LayoutInflater.from(context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: QuestionListAdapter.MyViewHolder, position: Int) {
        var Quest = quesList[position]
        holder.binding.tvQuest.text = "${Quest.que}"
         holder.binding.cardView.setOnClickListener {
             when(Quest.id){
                 1->{
                     val intent = Intent(context,ReverseNumberActivity::class.java)
                     context.startActivity(intent)
                 }
                 2->{
                     val intent = Intent(context,NumberBetweenActivity::class.java)
                     context.startActivity(intent)
                 }
                 3->{
                     val intent = Intent(context,CalculatorActivity::class.java)
                     context.startActivity(intent)
                 }
                 4->{
                     val intent = Intent(context,MainActivity2::class.java)
                     context.startActivity(intent)
                 }
                 5->{
                     val intent = Intent(context,WebView::class.java)
                     context.startActivity(intent)
                 }
                 8->{
                     val intent = Intent(context,VisibleTextActivity::class.java)
                     context.startActivity(intent)
                 }
                 9->{
                     val intent = Intent(context,TableLayoutActivity::class.java)
                     context.startActivity(intent)
                 }
                 10->{
                     val intent = Intent(context,PdfActivity::class.java)
                     context.startActivity(intent)
                 }
                 11->{
                     val intent = Intent(context,FontSizeActivity::class.java)
                     context.startActivity(intent)
                 }
                 12->{
                     val intent = Intent(context,NTextViewActivity::class.java)
                     context.startActivity(intent)
                 }
                 13->{
                     val intent = Intent(context,CheckboxActivity::class.java)
                     context.startActivity(intent)
                 }
                 14->{
                     val intent = Intent(context,StringArrayActivity::class.java)
                     context.startActivity(intent)
                 }
                 15->{
                     val intent = Intent(context,ScreenColorActivity::class.java)
                     context.startActivity(intent)
                 }
                 17->{
                     val intent = Intent(context,CustomToolbarActivity::class.java)
                     context.startActivity(intent)
                 }
                 18->{
                     val intent = Intent(context,CustomToolbarActivity::class.java)
                     context.startActivity(intent)
                 }
             }
         }
    }


    override fun getItemCount(): Int {
        return quesList.size
    }
}