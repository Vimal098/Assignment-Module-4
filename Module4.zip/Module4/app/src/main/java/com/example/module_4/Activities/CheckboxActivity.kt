package com.example.module_4.Activities

import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.view.isVisible
import com.example.module_4.R
import com.example.module_4.databinding.ActivityCheckboxBinding

class CheckboxActivity : AppCompatActivity() {
    private lateinit var binding : ActivityCheckboxBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCheckboxBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.checkBox.setOnCheckedChangeListener { button, b ->
            if (button.isChecked){
                binding.tvText.isVisible = true
            }
            else binding.tvText.isVisible = false
        }
    }
}